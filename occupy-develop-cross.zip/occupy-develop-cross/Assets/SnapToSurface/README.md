# Snap To Surface

This adds an option to the Window menu to open up a little editor utility that uses Unity's physics to snap objects to surfaces in any of the six primary axis. Great for aligning objects with the ground or a wall.
